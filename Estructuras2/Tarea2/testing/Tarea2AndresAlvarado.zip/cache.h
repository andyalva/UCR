#ifndef CACHE_H
#define CACHE_H

#include <cmath>
#include <iostream>

typedef unsigned long ulong;
typedef unsigned char uchar;
typedef unsigned int uint;

enum
{
  INVALID = 0,
  VALID,
  DIRTY,
  SHARED,
  MODIFIED,
  EXCLUSIVE,
  SHARED_CLEAN,
  SHARED_MODIFIED,
  EMPTY
};

class cacheLine
{
protected:
  ulong tag;
  ulong Flags; // 0:INVALID, 1:SHARED, 2:MODIFIED
  ulong seq;

public:
  cacheLine()
  {
    tag = 0;
    Flags = 0;
  }
  ulong getTag() { return tag; }
  ulong getFlags() { return Flags; }
  ulong getSeq() { return seq; }
  void setSeq(ulong Seq) { seq = Seq; }
  void setFlags(ulong flags) { Flags = flags; }
  void setTag(ulong a) { tag = a; }
  void invalidate()
  {
    tag = 0;
    Flags = INVALID;
  }
  bool isValid() { return ((Flags) != INVALID); }
};

class Cache
{
protected:
  ulong size, lineSize, assoc, sets, log2Sets, log2Blk, tagMask, numLines;
  ulong reads, readMisses, writes, writeMisses, writeBacks;

  cacheLine **cache;
  ulong calcTag(ulong addr) { return (addr >> (log2Blk)); }
  ulong calcIndex(ulong addr) { return ((addr >> log2Blk) & tagMask); }
  ulong calcAddr4Tag(ulong tag) { return (tag << (log2Blk)); }

public:
  ulong currentCycle;

  ulong num_of_cache_to_cache_transfer;
  ulong num_of_flushes;
  ulong num_of_interventions;
  ulong num_of_invalidations;
  ulong num_of_mem_trans;

  Cache(int, int, int);
  ~Cache() { delete cache; }

  cacheLine *findLineToReplace(ulong addr);
  cacheLine *fillLine(ulong addr);
  cacheLine *findLine(ulong addr);
  cacheLine *getLRU(ulong);

  ulong getRM() { return readMisses; }
  ulong getWM() { return writeMisses; }
  ulong getReads() { return reads; }
  ulong getWrites() { return writes; }
  ulong getWB() { return writeBacks; }

  void writeBack(ulong) { writeBacks++; }
  void Access(ulong, uchar);
  void printStats();
  void updateLRU(cacheLine *);
};

#endif
