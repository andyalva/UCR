#include "bus.cpp"
#include "cpu.cpp"
#include "cache.cpp"

void main(){
	CPU1 = CPU(1);
	CPU2 = CPU(2);


};
