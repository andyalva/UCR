//Protocolo MESI
char MESI_m = 'm';
char MESI_e = 'e';
char MESI_s = 's';
char MESI_i = 'i';

//Condicion inicial del protocolo MESI
char MESI_init = MESI_i

//Condicion inicial del valid bit
int BIT_V = 0
